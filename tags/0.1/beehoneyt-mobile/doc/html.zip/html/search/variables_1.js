var searchData=
[
  ['clientid',['clientId',['../classcom_1_1lasalle_1_1beehoneyt_1_1_communication_m_q_t_t.html#a71afaaefc131d8379561bcef68c78646',1,'com::lasalle::beehoneyt::CommunicationMQTT']]],
  ['communicationmqtt',['communicationMQTT',['../classcom_1_1lasalle_1_1beehoneyt_1_1_main_activity.html#aaf5caf592f40b944b1c643a92f91b944',1,'com::lasalle::beehoneyt::MainActivity']]]
];
