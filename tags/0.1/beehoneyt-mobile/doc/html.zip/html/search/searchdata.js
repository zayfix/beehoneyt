var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstu",
  1: "cmr",
  2: "c",
  3: "cmr",
  4: "acdefgors",
  5: "acdehilmnprstu",
  6: "abclr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Pages"
};

