var searchData=
[
  ['useappcontext',['useAppContext',['../classcom_1_1lasalle_1_1beehoneyt_1_1_example_instrumented_test.html#aca2066d94b15d86aa17700bad11c3f40',1,'com::lasalle::beehoneyt::ExampleInstrumentedTest']]]
];
