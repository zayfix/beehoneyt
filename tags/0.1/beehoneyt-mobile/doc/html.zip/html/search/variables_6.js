var searchData=
[
  ['layoutmanager',['layoutManager',['../classcom_1_1lasalle_1_1beehoneyt_1_1_main_activity.html#a36334ebc912014ea4846ae25ebfc3941',1,'com::lasalle::beehoneyt::MainActivity']]]
];
