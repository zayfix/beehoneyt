var searchData=
[
  ['adapter',['adapter',['../classcom_1_1lasalle_1_1beehoneyt_1_1_main_activity.html#a96cb46123756b3bcd10cb0dbfd2a2764',1,'com::lasalle::beehoneyt::MainActivity']]]
];
