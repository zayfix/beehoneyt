var searchData=
[
  ['serveruri',['serverUri',['../classcom_1_1lasalle_1_1beehoneyt_1_1_communication_m_q_t_t.html#aaf4f8561e67fd2f60a199cd9f2ea9deb',1,'com::lasalle::beehoneyt::CommunicationMQTT']]],
  ['swiperefreshlayout',['swipeRefreshLayout',['../classcom_1_1lasalle_1_1beehoneyt_1_1_main_activity.html#a5033248abadbd8e1710e9458eec76e95',1,'com::lasalle::beehoneyt::MainActivity']]]
];
