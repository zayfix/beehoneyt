var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuv~",
  1: "ciqr",
  2: "u",
  3: "cimnr",
  4: "acdefgimnosv~",
  5: "acehilmnprstu",
  6: "p",
  7: "p",
  8: "anv",
  9: "abclr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Énumérations",
  7: "Valeurs énumérées",
  8: "Macros",
  9: "Pages"
};

