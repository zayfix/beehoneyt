var searchData=
[
  ['settings',['settings',['../class_configuration.html#a6a70f47cb50e7df1a2c089e0a25a0e19',1,'Configuration']]],
  ['subscription',['subscription',['../class_communication.html#aed204510766ef07e06ecb5d281047fb3',1,'Communication']]]
];
